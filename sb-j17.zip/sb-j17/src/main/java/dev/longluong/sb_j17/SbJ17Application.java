package dev.longluong.sb_j17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbJ17Application {

	public static void main(String[] args) {
		SpringApplication.run(SbJ17Application.class, args);
	}

}

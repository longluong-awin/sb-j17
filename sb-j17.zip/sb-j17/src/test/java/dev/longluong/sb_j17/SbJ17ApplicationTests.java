package dev.longluong.sb_j17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbJ17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
